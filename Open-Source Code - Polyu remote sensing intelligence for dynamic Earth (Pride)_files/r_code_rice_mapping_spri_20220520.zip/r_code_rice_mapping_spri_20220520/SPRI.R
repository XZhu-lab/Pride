#################################################
#######   Code of SPRI for rice mapping  #######
##        coded by Shuai Xu, Zhu Xiaolin 
##     The Hong Kong Polytechnic University
##            version: 20 May 2022
##Please contact shuai.xu@connect.polyu.hk 
##               xlzhu@polyu.edu.hk
##        Copyright belongs to Zhu Xiaolin
#################################################

#####################Part 1######################
#######          Data description         #######
#################################################
##1. Sentinel-1 time series (e.g., Testdata_VH.tif)
##2. NDVImax and NDWImax    (e.g., Testdata _NDVImax.tif)
##3. Shapefile of objects   (e.g., Testdata_shapefile.tif)

#####################Part 2######################
#######        Required R packages        #######
#######          R version 4.1.3          #######
#################################################
install.packages("rgdal")
install.packages("maps")
install.packages("mapproj")
install.packages("raster")
install.packages("sf")
install.packages("exactextractr")
install.packages("svDialogs")
library(rgdal)         # shapefile operation 
library(maps)          # map operation
library(mapproj)       # map projection
library(raster)        # tif input
library(sf)
library(exactextractr) # zonal statistics
library(svDialogs)

#####################Part 3######################
#######         Basic information         #######
#######                                   #######
#################################################
#set work directory
directory <- dlg_dir(title = "Select the folder where code is stored")$res
setwd(directory)

#set parameters
source("interact.R")


#####################Part 4######################
#######         Index calculation         #######
#################################################
######## readin data
Sentinel1 <- stack(dlg_open(title = "Select Sentinel-1 VH time series",multiple = TRUE)$res)        # readin SAR time series      
NDVI <- stack(dlg_open(title = "Select NDVImax file",multiple = TRUE)$res)          # readin NDVImax
NDWI <- stack(dlg_open(title = "Select NDWImax file",multiple = TRUE)$res)          # readin NDWImax
Shapefile <- dlg_open(title = "Select shapefile",multiple = TRUE)$res
Validation = readOGR(Shapefile)       # for result output
Training   = st_read(Shapefile)       # for zonal statistic

##Zonal statistic
Sentinel_zonal <- exact_extract(Sentinel1, Training, 'mean')
NDVI_zonal     <- exact_extract(NDVI, Training, 'mean')
NDWI_zonal   <- exact_extract(NDWI, Training, 'mean')

##Data format transition for quick calculation
Sentinel_zonal_matrix <- as.matrix(Sentinel_zonal) # from dataframe to matrix
NDVI_zonal_matrix     <- as.matrix(NDVI_zonal)
NDWI_zonal_matrix     <- as.matrix(NDWI_zonal)

rownum = nrow(Sentinel_zonal_matrix) # number of row
colnum = ncol(Sentinel_zonal_matrix) # number of column

######## Sentinel-1 time series temporal filter
Sl_filtered  = Sentinel_zonal_matrix
TurningPoint = Sl_filtered

for (i in 1:rownum){
   open = 1 # Determine if iterative filtering is required
   while(open > 0){
        for (j in 2:colnum){
            TurningPoint[i,j] <- Sl_filtered[i,j-1] - Sl_filtered[i,j]
                        }
        TurningPoint[is.na(TurningPoint[])] <- 0 
        for (j in 1:colnum){
            if (TurningPoint[i,j]>0){
                TurningPoint[i,j] <- 1
                           }
            else{
        TurningPoint[i,j] <- -1
                 }
                         }

        for (j in 2:(colnum-1)){
            TurningPoint[i,j] <- TurningPoint[i,j] - TurningPoint[i,j+1]
                            }

        open <- 0
        for (j in 2:(colnum-1)){
           if (TurningPoint[i,j]==-2){
           ex1 <- j+1
           while(TurningPoint[i,ex1]!=-2 & ex1< (colnum-1)) {ex1 <- ex1 + 1}
        
           if ((ex1-j)<4 & (ex1-j)>1 & ex1< (colnum-1) & (min(Sl_filtered[i,j:ex1])!=min(Sl_filtered[i,1:colnum]))) {
          for (temp in j:ex1) {Sl_filtered[i,temp] <- Sl_filtered[i,j]+(temp-j)*(Sl_filtered[i,ex1]-Sl_filtered[i,j])/(ex1-j)
          open <- 1
}
}    
}
}

}
}

######## Extract local maximum and minimum points (p1,p2)
TurningPoint = Sentinel_zonal_matrix
Localmaxmin = TurningPoint

# Second order difference method
for (i in 1:rownum){
   for (j in 2:colnum){
     TurningPoint[i,j] <- Sl_filtered[i,j-1] - Sl_filtered[i,j]
}
}

TurningPoint[is.na( TurningPoint[])] <- 0 

for (i in 1:rownum){
   for (j in 1:colnum){
     if (TurningPoint[i,j]>0){
        TurningPoint[i,j] <- 1
}
     else{
        TurningPoint[i,j] <- -1
}
}
}

for (i in 1:rownum){
   for (j in 2:(colnum-1)){
     TurningPoint[i,j] <- TurningPoint[i,j]-TurningPoint[i,j+1]
}
}

# find all potential local minimum and maximum point
for (i in 1:rownum){
   for (j in 2:(colnum-1)){
     if (TurningPoint[i,j]==2&(TurningPoint[i,j-1]==0|TurningPoint[i,j+1]==0)){
       Localmaxmin[i,j]<-2     # local minimum point
}
     else if (TurningPoint[i,j]==-2&TurningPoint[i,j-1]==0&TurningPoint[i,j+1]==0){
       Localmaxmin[i,j]<--2    # local maximum point
}
     else{Localmaxmin[i,j]<-0} # not a breakingpoint
}
}



######## Determine parameter W and V
#################################################
Validation_wv          <- as.data.frame(Validation)
rownum_wv = nrow(Validation_wv)
colnum_wv = ncol(Validation_wv)
Validation_wv$NDVImax  <- NDVI_zonal
Validation_wv$NDWImax  <- NDWI_zonal
Validation_wv$Vline    <- 0
Validation_wv$Wline    <- 0

for (i in 1:rownum_wv){
    Validation_wv[i,colnum_wv+3] <- quantile(Sl_filtered[i,1:colnum],0.95,na.rm=TRUE)
    Validation_wv[i,colnum_wv+4] <- quantile(Sl_filtered[i,1:colnum],0.05,na.rm=TRUE)
}

ndf1 <- subset(Validation_wv, NDVImax >= 0.4 )
ndf2 <- subset(Validation_wv, NDVImax >= 0.4 & NDWImax >= 0.3 )

V <- quantile(ndf1[,colnum_wv+3],V_percentile)
W <- quantile(ndf2[,colnum_wv+4],W_percentile)


if (nrow(ndf1) < 50) {
warning("The sample size for V line value is too small!") 
warning("The V line value will use the default parameter!") 
       if (first == "yes") { V <- -18 }             
       if (first == "no")  { V <- -16 }

}

if (nrow(ndf2) < 50) {
warning("The sample size for W line value is too small!") 
warning("The W line value will use the default parameter!") 

       if (first == "yes") { W <- -28 }             
       if (first == "no")  { W <- -22 }

}


VW <- V - W



######## SPRI calculation
sigmoid = function(x){1/(1+exp(x))}
for (i in 1:rownum){
   if (mean(Sl_filtered[i,]) > V | mean(Sl_filtered[i,]) < W) {Localmaxmin[i,] <- 0}
    for (j in 1:colnum){ 
      if (Localmaxmin[i,j]==2) {
         p1 = max(Sl_filtered[i,j],W)
         m <- min(j+1,colnum)
         while(Localmaxmin[i,m]!=2&m<colnum){m <- m+1}
         p2 = min(max(Sl_filtered[i,j:m]),V)
         p1j = which.max(Sl_filtered[i,j:m])+j-1
         n <- min(m,colnum)
         while(Localmaxmin[i,n]!=-2&n<colnum){n <- n+1}
         if (Sl_filtered[i,j]<Sl_filtered[i,m]&(n-j)<14&n!=colnum&max(Sl_filtered[i,j:m])<Sl_filtered[i,n]) {
            p2 = min(Sl_filtered[i,n],V)
            p1j = n}
         Dtemp  = (p2 - p1)/VW
         D  = max(Dtemp,0)    
         spd = VW * (1-D) - VW / 2
         sig <- sigmoid(spd)  ## Component D
         WP = abs(p1-W)/VW    ## Component W
         VP = abs(p2-V)/VW    ## Component V
         Localmaxmin[i,j] <- sig * (1-WP^2)*(1-VP^2) ## Index value at the given date
}  
      else {Localmaxmin[i,j] <- 0}

}
}


Outputfile <- data.frame(cbind(NDVI_zonal,NDWI_zonal))
Outputfile$prob_result <- 0
Outputfile$date_result <- 0

for (i in 1:rownum){
   Outputfile[i,3] = max(Localmaxmin[i, 1:colnum]) # the maximum calculated rice planted probability
   # The user can change the search period based on your field data to get a more accurate result
   Outputfile[i,4] = (which.max(Localmaxmin[i,1:colnum])-1)*12+Firstdate
   # the corresponding date with the highest probability
}

Validation$Rice_prob <- Outputfile$prob_result
Validation$Date <- Outputfile$date_result

#Output SPRI result
writeOGR(Validation,".","Result_output",driver="ESRI Shapefile")
